const { Builder } = require('selenium-webdriver');
const assert = require('assert');
const browsers = ['chrome', 'firefox','safari'];

describe('Cross-Browser Compatibility Tests', function () {
    browsers.forEach(function (browser) {
        it(`should render correctly in ${browser}`, async function () {
            const driver = await new Builder().forBrowser(browser).build();

            // Navigate to the site
            await driver.get('https://your-static-site.com');
            
            // Check if the title is correct (this is a simple check, you can add more checks for other elements)
            const title = await driver.getTitle();
            assert.strictEqual(title, 'Expected Title');
            
            // Add any other checks for specific elements, responsive behavior, or JavaScript execution
            
            await driver.quit();
        });
    });
});
