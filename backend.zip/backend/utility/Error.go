package utility

type Error struct {
	message string
	error   string
	code    int
}
