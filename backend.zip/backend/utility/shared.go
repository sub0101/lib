package utility

import (
	"strconv"

	"github.com/gin-gonic/gin"
)

var RequestTypes = map[string]bool{"issue": true, "return": true}
var IssueStatusTypes = map[string]bool{"accepted": true, "rejected": true}
var roles = []string{"admin", "reader", "owner"}

func GetQueryItem(c *gin.Context, id string) uint {
	idQuery := c.Query(id)

	retid, _ := strconv.Atoi(idQuery)

	return uint(retid)
}

func GetContextItem(c *gin.Context, id string) uint {
	userId, _ := c.Get(id)
	result := uint(userId.(float64))
	return result
}
func GetParamItem(c *gin.Context, id string) (uint, bool) {
	idParams, exist := c.Params.Get(id)
	result, _ := strconv.Atoi(idParams)
	if result == 0 {
		return 0, false
	}
	return uint(result), exist

}
