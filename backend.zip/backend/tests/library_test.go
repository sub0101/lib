package tests

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestUpdateLibrary(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()

	tests := []struct {
		name          string
		payload       map[string]interface{}
		token         string
		expectedCode  int
		expectedError string
	}{
		{
			name:  "Update_Library_Details_By_Owner",
			token: testOwnerToken,
			payload: map[string]interface{}{
				"name": "West Coast Library",
			},
			expectedCode: 200,
		},
		{
			name:  "Update_Library_Details_With_Invalid_Body",
			token: testOwnerToken,
			payload: map[string]interface{}{
				"name": "West Coast Library.k.",
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
		{
			name:  "Update_Library_Details_With_Invalid_Body",
			token: testOwnerToken,
			payload: map[string]interface{}{
				"nme": "West Coast Library",
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
		{
			name: "Update_Library_Details_By_Unauthorized_User",
			payload: map[string]interface{}{
				"name": "West Coast Library",
			},
			expectedCode:  401,
			expectedError: "unauthorized",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, _ := json.Marshal(tt.payload)
			req, _ := http.NewRequest("PATCH", "/api/v1/library/", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tt.token)
			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)

			if tt.expectedCode == 401 {
				var response map[string]interface{}
				json.Unmarshal(res.Body.Bytes(), &response)
				assert.Contains(t, response["message"], tt.expectedError)
			}

		})

	}
	stopTransaction()
}

func TestGetLibraryDetail(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()

	tests := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
	}{
		{
			name:         "Get_Library_Details_By_Owner",
			token:        testOwnerToken,
			expectedCode: 200,
		},
		{
			name:          "Get_Library_Details_Without_Login",
			token:         "",
			expectedCode:  401,
			expectedError: "unauthorized",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", "/api/v1/library/", nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tt.token)
			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)

			if tt.expectedCode == 401 {
				var response map[string]interface{}
				json.Unmarshal(res.Body.Bytes(), &response)
				assert.Contains(t, response["message"], tt.expectedError)
			}

		})

	}
	stopTransaction()
}

func TestGetAllLibrary(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()

	tests := []struct {
		name          string
		expectedCode  int
		expectedError string
	}{
		{
			name: "Get_All_Library",

			expectedCode: 200,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", "/api/v1/library/all", nil)
			req.Header.Set("Content-Type", "application/json")

			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)

		})

	}
	stopTransaction()
}
