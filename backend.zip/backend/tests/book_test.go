package tests

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestAddBooks(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()

	jwtToken := GetJwtOwnerToken()

	tests := []struct {
		name          string
		book          map[string]interface{}
		token         string // JWT token (valid or empty)
		expectedCode  int
		expectedError string
	}{
		{
			name: "Add_Valid_Book",
			book: map[string]interface{}{
				"isbn":            "9756523612",
				"title":           "bookqw",
				"authors":         "authoro",
				"publisher":       "publishero",
				"version":         "1.1.1",
				"totalCopies":     150,
				"availableCopies": 150,
			},
			token:        jwtToken,
			expectedCode: 201,
		},
		{
			name: "Add_Duplicate_Book",
			book: map[string]interface{}{
				"isbn":            "9756523612",
				"title":           "bookqw",
				"authors":         "authoro",
				"publisher":       "publishero",
				"version":         "1.1.1",
				"totalCopies":     100,
				"availableCopies": 100,
			},
			token:        jwtToken,
			expectedCode: 201,
		},
		{
			name: "Add_Book_With_Invalid_Copies",
			book: map[string]interface{}{
				"isbn":            "9756521212",
				"title":           "bookqw",
				"authors":         "authoro",
				"publisher":       "publishero",
				"version":         "1.1.1",
				"totalCopies":     70,
				"availableCopies": 150,
			},
			token:        jwtToken,
			expectedCode: 400,
		},
		{
			name: "Unauthorized_User_Adding_Book",
			book: map[string]interface{}{
				"isbn":            "9756523611",
				"title":           "bookqw",
				"authors":         "authoro",
				"publisher":       "publishero",
				"version":         "1.1.1",
				"totalCopies":     150,
				"availableCopies": 150,
			},
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
		},
		{
			name: "Add_Book_With_Invalid_Payload",
			book: map[string]interface{}{
				"isbn":            "9756523",
				"titl":            "bookqw12",
				"authors":         "authoro1",
				"publisher":       "publishero",
				"version":         "1.1.1",
				"totalCopies":     150,
				"availableCopies": 150,
			},
			token:         jwtToken,
			expectedCode:  400,
			expectedError: "invalid payload",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tc.book)
			if err != nil {
				t.Fatalf("Failed to marshal book: %v", err)
			}

			req, _ := http.NewRequest("POST", "/api/v1/books/", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")

			if tc.token != "" {
				req.Header.Set("Authorization", "Bearer "+tc.token)
			}

			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestGetAllBooks(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()

	tests := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
	}{
		{
			name:          "Get_All_Books_As_Owner",
			token:         GetJwtOwnerToken(),
			expectedCode:  200,
			expectedError: "",
		},
		{
			name:          "Get_All_Books_As_Reader",
			token:         GetJwtUserToken(),
			expectedCode:  200,
			expectedError: "",
		},
		{
			name:          "Get_All_Books_Without_JWT",
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", "/api/v1/books/", nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tc.token)
			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)
		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestGetBookDetail(t *testing.T) {

	router := SetupRouter()
	libId, _ := SetupTestLibrary()
	SetupTestUsers()
	tempOwnerToken, _ := CreateTempOwner()

	bookId := CreateTempBook(libId)

	tests := []struct {
		name          string
		token         string
		expectedCode  int
		params        int
		expectedError string
	}{
		{
			name:          "Get_Book_By_Valid_Id_As_Owner_Should_Return_200",
			token:         GetJwtOwnerToken(),
			params:        int(bookId),
			expectedCode:  200,
			expectedError: "",
		},
		{
			name:          "Get_Book_Without_Login_Should_Return_401",
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
			params:        int(bookId),
		},
		{
			name:          "Get_Book_As_Unauthorized_User_Should_Return_403",
			token:         tempOwnerToken,
			expectedCode:  403,
			expectedError: "Not Authorized to Access This Resource",
			params:        int(bookId),
		},
		{
			name:          "Get_Book_Without_Id_Parameter_Should_Return_400",
			token:         GetJwtUserToken(),
			expectedCode:  400,
			expectedError: "Invalid Params",
		},
		{
			name:          "Get_Book_With_Ivalid_Id_Should_Return_404",
			token:         testOwnerToken,
			expectedCode:  404,
			params:        121,
			expectedError: "not found",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", fmt.Sprintf("/api/v1/books/%d", tc.params), nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tc.token)
			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestUpdateBook(t *testing.T) {

	router := SetupRouter()
	libId, _ := SetupTestLibrary()
	readerId := SetupTestUsers()
	GetJwtOwnerToken()
	_ = readerId
	tempOwnerToken, _ := CreateTempOwner()

	bookId := CreateTempBook(libId)

	tests := []struct {
		name          string
		token         string
		expectedCode  int
		book          map[string]interface{}
		expectedError string
		params        int
	}{
		{
			name:   "Update_Book_By_Valid_Id_As_Owner_Should_Return_201",
			token:  GetJwtOwnerToken(),
			params: int(bookId),
			book: map[string]interface{}{
				"availableCopies": 100,
			},
			expectedCode: 201,
		},
		{
			name:   "Update_Book_By_valid_Id_As_UnAuthorized_User_Should_Return_404",
			token:  tempOwnerToken,
			params: int(bookId),
			book: map[string]interface{}{
				"availableCopies": 100,
			},
			expectedCode: 403,
		},
		{
			name:          "Update_Book_Without_Login_Should_Return_401",
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
			params:        int(bookId),
		},
		{
			name:  "Update_Book_With_Invalid_Book_Id_Should_Return_404",
			token: testOwnerToken,

			expectedCode:  404,
			expectedError: "Book Not Found",
			params:        121,
		},
		{
			name:          "Update_Book_As_Unauthorized_User_Should_Return_403",
			token:         tempOwnerToken,
			expectedCode:  403,
			expectedError: "Cannot Update Book",
			params:        int(bookId),
		},
		{
			name:         "Update_Book_Without_Book_Id_Parameter_Should_Return_400",
			token:        GetJwtOwnerToken(),
			expectedCode: 400,
			book: map[string]interface{}{
				"availableCopies": 100,
			},
			expectedError: "Invalid Params",
		},
		{
			name:         "Update_Book_With_Invalid_Payload_Should_Return_400",
			token:        GetJwtOwnerToken(),
			expectedCode: 400,
			book: map[string]interface{}{
				"availableCopies": "1212",
			},
			expectedError: "Invalid body",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tc.book)
			if err != nil {
				t.Fatalf("Failed to marshal book: %v", err)
			}

			req, _ := http.NewRequest("PATCH", fmt.Sprintf("/api/v1/books/%d", tc.params), bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tc.token)
			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestDeleteBook(t *testing.T) {

	router := SetupRouter()
	libId, _ := SetupTestLibrary()
	readerId := SetupTestUsers()
	_ = readerId
	tempOwnerToken, _ := CreateTempOwner()

	bookId := CreateTempBook(libId)

	tests := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
		params        int
	}{
		{
			name:          "Delete_Book_With_Valid_Id_As_Owner_Should_Return_200",
			token:         GetJwtOwnerToken(),
			params:        int(bookId),
			expectedCode:  200,
			expectedError: "",
		},
		{
			name:          "Delete_Book_With_Invalid_Id_As_Owner_Should_Return_404",
			token:         GetJwtOwnerToken(),
			params:        121,
			expectedCode:  404,
			expectedError: "",
		},
		{
			name:          "Delete_Book_With_Valid_Id_But_No_Copies_Left_Should_Return_400",
			token:         GetJwtOwnerToken(),
			params:        int(bookId),
			expectedCode:  400,
			expectedError: "No copies left to delete",
		},
		{
			name:          "Delete_Book_Without_Login_Should_Return_401",
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
			params:        int(bookId),
		},
		{
			name:          "Delete_Book_As_Unauthorized_User_Should_Return_403",
			token:         tempOwnerToken,
			expectedCode:  403,
			expectedError: "You are not authorized to access this resource",
			params:        int(bookId),
		},
		{
			name:          "Delete_Book_Without_Params_Id_Should_Return_400",
			token:         GetJwtOwnerToken(),
			expectedCode:  400,
			expectedError: "Invalid Params",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			req, _ := http.NewRequest("DELETE", fmt.Sprintf("/api/v1/books/%d", tc.params), nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tc.token)
			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

		})
	}
	stopTransaction()

	// TearDownTestDB()
}

func TestGetIssuedBook(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()

	tests := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
	}{
		{
			name:         "Get_All_Issued_Books_With_Valid_Token",
			token:        GetJwtUserToken(),
			expectedCode: 200,
		},
		{
			name:          "Get_All_Issued_Books_Without_Token",
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", "/api/v1/books/issued", nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tc.token)
			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

			// if tc.expectedCode == 200 {
			// 	var books []models.BookInventory
			// 	json.Unmarshal(w.Body.Bytes(), &books)
			// 	assert.GreaterOrEqual(t, len(books), 0)
			// }
		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestSeachBook(t *testing.T) {

	router := SetupRouter()
	libId, _ := SetupTestLibrary()
	SetupTestUsers()
	CreateTempBook(libId)
	tempToken, _ := CreateTempOwner()

	tests := []struct {
		name          string
		token         string
		searchBody    map[string]interface{}
		expectedCode  int
		expectedError string
	}{
		{
			name:  "Search_Books_With_Valid_Token",
			token: GetJwtUserToken(),
			searchBody: map[string]interface{}{
				"isbn":  "9756523612",
				"title": "Book1",
			},
			expectedCode: 200,
		},
		{
			name:  "Search_Books_By_Unauthorized_User",
			token: tempToken,
			searchBody: map[string]interface{}{
				"isbn":  "9756523612",
				"title": "Book1",
			},
			expectedCode:  404,
			expectedError: "not found",
		},
		{
			name:          "Search_Books_Without_Token",
			token:         "",
			expectedCode:  401,
			expectedError: "Invalid Token",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			jsonData, _ := json.Marshal(tc.searchBody)
			req, _ := http.NewRequest("GET", "/api/v1/books/search", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tc.token)
			w := httptest.NewRecorder()

			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

		})
	}
	stopTransaction()
	// TearDownTestDB()
}
