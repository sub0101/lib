package tests

import (
	"bytes"
	"encoding/json"
	"libraryManagement/internal/dto"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestCreateLibrary(t *testing.T) {

	router := SetupRouter()
	validTestCases := []struct {
		name string
		dto.RequestSignupLibraryBody

		expectedCode  int
		expectedError string
	}{
		{
			name: "Signup_Succeeds_With_Valid_Input",
			RequestSignupLibraryBody: dto.RequestSignupLibraryBody{
				Name:          "suraj singh",
				Email:         "owner1@gmail.com",
				LibraryName:   "LibraryOne",
				ContactNumber: "9801232331",
				Password:      "Tvsbk0101@",
			},
			expectedCode:  201,
			expectedError: "",
		},
		{
			name: "Signup_Fails_When_Email_Already_Exists",
			RequestSignupLibraryBody: dto.RequestSignupLibraryBody{
				Name:          "suraj singh",
				Email:         "owner1@gmail.com",
				LibraryName:   "LibraryFive",
				ContactNumber: "1234567894",
				Password:      "Tvsbk0101@",
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
		{
			name: "Signup_Fails_When_Contact_Already_Exists",
			RequestSignupLibraryBody: dto.RequestSignupLibraryBody{
				Name:          "suraj singh",
				Email:         "owner1@gmail.com",
				LibraryName:   "LibraryFive",
				ContactNumber: "9801232331",
				Password:      "Tvsbk0101@",
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
		{
			name: "Signup_Fails_When_Library_Already_Exists",
			RequestSignupLibraryBody: dto.RequestSignupLibraryBody{
				Name:          "suraj singh",
				Email:         "owner111@gmail.com",
				LibraryName:   "LibraryOne",
				ContactNumber: "1234567894",
				Password:      "Tvsbk0101@",
			},
			expectedCode:  400,
			expectedError: "User Already Exist",
		},
		{
			name: "Signup_Fails_When_Email_Is_Missing",
			RequestSignupLibraryBody: dto.RequestSignupLibraryBody{
				Name: "suraj singh",

				LibraryName:   "LibraryFive",
				ContactNumber: "1234567894",
				Password:      "Tvsbk0101@",
			},
			expectedCode:  400,
			expectedError: "User Already Exist",
		},
		{
			name: "Signup_Fails_When_Contact_Number_Already_Exists",
			RequestSignupLibraryBody: dto.RequestSignupLibraryBody{
				Name:  "suraj singh",
				Email: "owner111@gmail.com",

				LibraryName:   "LibraryOne",
				ContactNumber: "1234567894",
				Password:      "Tvsbk0101@",
			},
			expectedCode:  400,
			expectedError: "user already exist",
		},
	}

	for _, tc := range validTestCases {
		t.Run(tc.name, func(t *testing.T) {
			jsonData, _ := json.Marshal(tc.RequestSignupLibraryBody)

			req, _ := http.NewRequest("POST", "/api/v1/auth/library/signup", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")

			w := httptest.NewRecorder()
			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestLoginUser(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	var validTestCases = []struct {
		name string
		dto.RequestLoginBody
		expectedCode  int
		expectedError string
	}{
		{
			name: "Login_Succeeds_With_Valid_Credentials",
			RequestLoginBody: dto.RequestLoginBody{
				Email:    "owner1@example.com",
				Password: "Tvsbk0101@",
			},
			expectedCode:  200,
			expectedError: "",
		},
		{
			name: "Login_Fails_With_Invalid_Credentials",
			RequestLoginBody: dto.RequestLoginBody{
				Email:    "user2@gmail.com",
				Password: "Tvsbk0102@",
			},
			expectedCode:  400,
			expectedError: "invalid email or password",
		},
		{
			name: "Login_Fails_When_Password_Is_Incorrect",
			RequestLoginBody: dto.RequestLoginBody{
				Email:    "user1@gmail.com",
				Password: "Tvsbk0102@",
			},
			expectedCode:  400,
			expectedError: "invalid email or password",
		},
		{
			name: "Login_Fails_When_Email_Is_Missing",
			RequestLoginBody: dto.RequestLoginBody{
				Password: "Tvsbk0102@",
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
		{
			name: "Login_Fails_When_Email_Format_Is_Invalid",
			RequestLoginBody: dto.RequestLoginBody{
				Email:    "dddgmail.com",
				Password: "Tvsbk0102@",
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
	}

	for _, tc := range validTestCases {
		t.Run(tc.name, func(t *testing.T) {
			jsonData, _ := json.Marshal(tc.RequestLoginBody)

			req, _ := http.NewRequest("POST", "/api/v1/auth/login", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")

			w := httptest.NewRecorder()
			router.ServeHTTP(w, req)

			assert.Equal(t, tc.expectedCode, w.Code)

			if tc.expectedCode == 400 || tc.expectedCode == 401 || tc.expectedCode == 403 {
				var response map[string]interface{}
				json.Unmarshal(w.Body.Bytes(), &response)
				assert.Contains(t, response["message"], tc.expectedError)
			}
		})
	}
	stopTransaction()
}

func TestCreateReader(t *testing.T) {

	router := SetupRouter()
	libId, _ := SetupTestLibrary()
	SetupTestUsers()
	var validTestCases = []struct {
		name string
		dto.RequestSignupUserBody
		expectedCode  int
		expectedError string
	}{
		{
			name: "Signup_Succeeds_With_Valid_User",
			RequestSignupUserBody: dto.RequestSignupUserBody{
				Name:          "suraj singh",
				Email:         "suraj01@gmail.com",
				ContactNumber: "8734567895",
				Password:      "Tvsbk0101@",
				LibId:         libId,
			},
			expectedCode:  201,
			expectedError: "",
		},
		{
			name: "Signup_Fails_When_User_Already_Exists",
			RequestSignupUserBody: dto.RequestSignupUserBody{
				Name:          "suraj singh",
				Email:         "suraj01@gmail.com",
				ContactNumber: "9834567899",
				Password:      "Tvsbk0101@",
				LibId:         libId,
			},
			expectedCode:  400,
			expectedError: "user already exist",
		},
		{
			name: "Signup_Fails_When_Contact_Already_Exists",
			RequestSignupUserBody: dto.RequestSignupUserBody{
				Name:          "suraj singh",
				Email:         "suraj05@gmail.com",
				ContactNumber: "8734567895",
				Password:      "Tvsbk0101@",
				LibId:         libId,
			},
			expectedCode:  400,
			expectedError: "user already exist",
		},
		{
			name: "Signup_Fails_When_Library_Does_Not_Exist",
			RequestSignupUserBody: dto.RequestSignupUserBody{
				Name:          "suraj singh",
				Email:         "suraj02@gmail.com",
				ContactNumber: "7834567850",
				Password:      "Tvsbk0101@",
				LibId:         120,
			},
			expectedCode:  400,
			expectedError: "library does not exist",
		},
		{
			name: "Signup_Fails_When_Email_Or_Password_Is_Invalid",
			RequestSignupUserBody: dto.RequestSignupUserBody{
				Name:          "suraj singh",
				Email:         "surajgmail.com",
				ContactNumber: "12345678",
				Password:      "Tvsbk1",
				LibId:         libId,
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
		{
			name: "Signup_Fails_When_Email_Is_Missing",
			RequestSignupUserBody: dto.RequestSignupUserBody{
				Name:          "suraj singh",
				ContactNumber: "12345678",
				Password:      "Tvsbk1",
				LibId:         libId,
			},
			expectedCode:  400,
			expectedError: "invalid body",
		},
	}

	for _, tc := range validTestCases {
		t.Run(tc.name, func(t *testing.T) {
			jsonData, _ := json.Marshal(tc.RequestSignupUserBody)
			req, _ := http.NewRequest("POST", "/api/v1/auth/signup", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")
			w := httptest.NewRecorder()
			router.ServeHTTP(w, req)
			assert.Equal(t, tc.expectedCode, w.Code)
			if tc.expectedCode == 400 {
				var response map[string]interface{}
				json.Unmarshal(w.Body.Bytes(), &response)
				assert.Contains(t, response["message"], tc.expectedError)
			}
		})
	}
	// TearDownTestDB()
	stopTransaction()
}
