package tests

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestMakeAdmin(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	readerId := SetupTestUsers()
	log.Println(readerId)
	tempOwnerToken, _ := CreateTempOwner()

	_, tempReaderId := CreateTempReader()

	test := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
		params        uint
		body          map[string]interface{}
	}{
		{
			name:          "Make Admin",
			token:         testOwnerToken,
			expectedCode:  202,
			expectedError: "",
			body: map[string]interface{}{
				"id":   readerId,
				"role": "admin",
			},
		},
		{
			name:          "Make Admin By Unauthorized",
			token:         tempOwnerToken,
			expectedCode:  404,
			expectedError: "Forbidden",
			body: map[string]interface{}{
				"id":   readerId,
				"role": "admin",
			},
		},
		{
			name:          "Make Admin By invalid role",
			token:         testOwnerToken,
			expectedCode:  400,
			expectedError: "invalid role",
			body: map[string]interface{}{
				"id":   readerId,
				"role": "admisdfdsn",
			},
		},
		{
			name:          "Make Admin by invalid token",
			token:         "",
			expectedCode:  401,
			expectedError: "Unauthorized",
			body: map[string]interface{}{
				"id":   readerId,
				"role": "admin",
			},
		},
		{
			name:          "Make Admin to Unauthorized user",
			token:         testOwnerToken,
			expectedCode:  404,
			expectedError: "Forbidden",
			body: map[string]interface{}{
				"id":   tempReaderId,
				"role": "admin",
			},
		},
	}

	for _, tt := range test {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, _ := json.Marshal(tt.body)
			req, _ := http.NewRequest("PATCH", "/api/v1/users/make_admin", bytes.NewBuffer(jsonData))
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tt.token)
			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)
		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestGetUser(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	readerId := SetupTestUsers()
	tempOwnerToken, _ := CreateTempOwner()

	test := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
		params        uint
	}{
		{
			name:          "Get_User_By_Valid_Owner",
			token:         testOwnerToken,
			expectedCode:  202,
			expectedError: "",
			params:        readerId,
		},
		{
			name:          "Get_User_By_Valid_Reader",
			token:         testReaderToken,
			expectedCode:  202,
			expectedError: "",
			params:        readerId,
		},
		{
			name:          "Failed_To_Get_User_By_Unauthorized",
			token:         tempOwnerToken,
			expectedCode:  403,
			expectedError: "forbidden",
			params:        1,
		},
		{
			name:          "Failed_To_Get_User_By_Invalid_User_Id",
			token:         testOwnerToken,
			expectedCode:  404,
			expectedError: "not_found",
			params:        1121,
		},
		{
			name:          "Failed_To_Get_User_By_Invalid_Token",
			token:         "",
			expectedCode:  401,
			expectedError: "unauthorized_missing_token",
			params:        readerId,
		},
		{
			name:          "Failed_To_Get_User_By_Invalid_Params",
			token:         "",
			expectedCode:  401,
			expectedError: "unauthorized_missing_params",
		},
	}

	for _, tt := range test {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", fmt.Sprintf("/api/v1/users/%d", tt.params), nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tt.token)
			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)
		})
	}
	stopTransaction()
	// TearDownTestDB()
}

func TestGetAllUser(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	SetupTestUsers()
	// tempOwnerToken, _ := CreateTempOwner()

	test := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
	}{
		{
			name:          "Get_All_Users_By_Valid_Owner",
			token:         GetJwtOwnerToken(),
			expectedCode:  202,
			expectedError: "",
		},
		{
			name:          "Failed_To_Get_All_Users_By_Unauthorized_User",
			token:         GetJwtUserToken(),
			expectedCode:  403,
			expectedError: "forbidden",
		},
		{
			name:          "Failed_To_Get_All_Users_By_Invalid_Token",
			token:         "",
			expectedCode:  401,
			expectedError: "unauthorized_missing_token",
		},
	}

	for _, tt := range test {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := http.NewRequest("GET", "/api/v1/users/", nil)
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tt.token)
			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)
		})
	}
	// TearDownTestDB()
	stopTransaction()
}

func TestDeleteUser(t *testing.T) {

	router := SetupRouter()
	SetupTestLibrary()
	readerId := SetupTestUsers()
	tempOwnerToken, _ := CreateTempOwner()

	test := []struct {
		name          string
		token         string
		expectedCode  int
		expectedError string
		query         uint
	}{
		{
			name:          "Failed_To_Delete_User_By_Unauthorized",
			token:         tempOwnerToken,
			expectedCode:  403,
			expectedError: "forbidden",
			query:         readerId,
		},
		{
			name:          "Delete_User_By_Valid_Owner",
			token:         testOwnerToken,
			expectedCode:  202,
			expectedError: "",
			query:         readerId,
		},
		{
			name:          "Failed_To_Delete_User_By_Invalid_Token",
			token:         "",
			expectedCode:  401,
			expectedError: "unauthorized_missing_token",
			query:         readerId,
		},
		{
			name:          "Failed_To_Delete_User_By_Invalid_Query_Params",
			token:         testOwnerToken,
			expectedCode:  400,
			expectedError: "invalid_params_missing_query",
		},
	}

	for _, tt := range test {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := http.NewRequest("DELETE", "/api/v1/users/", nil)
			q := req.URL.Query()
			q.Add("id", fmt.Sprintf("%d", tt.query))
			req.URL.RawQuery = q.Encode() // Encode query back to URL

			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("Authorization", "Bearer "+tt.token)
			res := httptest.NewRecorder()
			router.ServeHTTP(res, req)
			assert.Equal(t, tt.expectedCode, res.Code)
		})
	}
	// TearDownTestDB()
	stopTransaction()
}
