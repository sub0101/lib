package library

import (
	"libraryManagement/app/middleware"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func SetupLibraryRouter(router *gin.RouterGroup, db *gorm.DB) {

	libraryController := NewLibraryController(db)
	libraryRouter := router.Group("/library")
	{
		libraryRouter.GET("/all", libraryController.GetAllLibrary)
		libraryRouter.Use(middleware.ValidateRefreshToken(db))

		libraryRouter.GET("/", middleware.IsAuth(), libraryController.GetLibrary)
		libraryRouter.PATCH("/", middleware.IsAuth("owner"), libraryController.UpdateLibrary)

	}

}
