package library

import (
	"libraryManagement/internal/dto"
	"libraryManagement/utility"
	"libraryManagement/validators"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type LibraryController struct {
	libraryService LibraryService
}

func NewLibraryController(db *gorm.DB) *LibraryController {

	service := LibraryService{db: db}
	return &LibraryController{libraryService: service}
}

func (lc *LibraryController) GetLibrary(c *gin.Context) {

	userId := utility.GetContextItem(c, "id")
	libId := utility.GetContextItem(c, "libId")

	libraries, err := lc.libraryService.GetLibrary(userId, libId)
	if err != nil {
		utility.SendResponse(c, 501, false, "Server Error", nil)
		return
	}

	utility.SendResponse(c, 200, true, "Successfully Fetched  library ", libraries)
}

func (lc *LibraryController) UpdateLibrary(c *gin.Context) {

	var payload dto.RequestUpdateLibrary
	userId := utility.GetContextItem(c, "id")
	libId := utility.GetContextItem(c, "libId")
	if err := c.ShouldBindJSON(&payload); err != nil {
		utility.SendResponse(c, 400, false, "invalid body", nil, err.Error())
		return
	}
	if err := validators.Validate.Struct(payload); err != nil {
		utility.SendResponse(c, 400, false, "invalid  body", nil, err.Error())

		// c.JSON(http.StatusBadRequest, gin.H{"validation_error": err.Error()})
		return
	}

	err := lc.libraryService.UpdateLibrary(userId, libId, payload)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, err.Details)
		return
	}
	utility.SendResponse(c, 200, true, "successfully updated the ibrary", nil)

}

func (lc *LibraryController) GetAllLibrary(c *gin.Context) {

	res, _ := lc.libraryService.GetAllLibrary()
	utility.SendResponse(c, 200, true, "Fetched All Library", res)
}
