package library

import (
	"libraryManagement/internal/dto"
	"libraryManagement/internal/models"
	"libraryManagement/utility/errorss"

	"gorm.io/gorm"
)

type LibraryService struct {
	db *gorm.DB
}

func (service *LibraryService) UpdateLibrary(userId, libId uint, payload dto.RequestUpdateLibrary) *errorss.AppError {
	db := service.db
	var user models.User
	if err := db.Where("lib_id=? AND id=?", libId, userId).First(&user).Error; err != nil {
		return errorss.NotFound("library not found", err.Error())
	}

	if err := db.Where("id = ?", libId).Updates(&models.Library{Name: payload.Name}).Error; err != nil {
		return errorss.InternalServerError("can not update", err.Error())
	}
	return nil

}
func (service *LibraryService) GetLibrary(userId uint, id uint) (map[string]interface{}, error) {
	db := service.db

	var library map[string]interface{}

	libObject := db.Where("ID = ? ", id).First(&library)
	libObject = db.Model(&models.Library{}).Where("ID = ? ", id).First(&library)
	if err := libObject.Error; err != nil {
		return nil, err
	}

	return library, nil

}

func (service *LibraryService) GetAllLibrary() ([]models.Library, error) {

	var response []models.Library

	db := service.db

	db.Model(&models.Library{}).Select("name", "id").Find(&response)
	return response, nil
}
