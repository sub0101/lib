package book

import (
	"fmt"
	auth "libraryManagement/app/modules/auth"
	"libraryManagement/internal/dto"
	"libraryManagement/internal/models"
	"libraryManagement/utility/errorss"
	"log"
	"time"

	"gorm.io/gorm"
)

type BookService struct {
	db *gorm.DB
}

var book models.BookInventory
var response dto.ResponseBookInfo
var user *models.User

func (bookService *BookService) AddBook(userId, libId uint, book models.BookInventory) (map[string]interface{}, *errorss.AppError) {

	db := bookService.db
	var response = make(map[string]interface{})

	if book.AvailableCopies != book.TotalCopies {
		return nil, errorss.BadRequest("Can not add Book", "Total copies are not equal to available copies")
	}

	var oldBook models.BookInventory
	isExist := db.Where("isbn=? AND lib_id=?", book.ISBN, libId).First(&oldBook)

	if err := isExist.Error; err == nil {
		oldBook.TotalCopies += book.TotalCopies
		oldBook.AvailableCopies += book.AvailableCopies
		updatedResult := db.Model(&models.BookInventory{}).Where("ID = ?", oldBook.ID).Updates(&models.BookInventory{TotalCopies: oldBook.TotalCopies, AvailableCopies: oldBook.AvailableCopies})
		// return errorss.BadRequest("Can not update the book", updatedResult.Error.Error())
		if updatedResult.Error != nil {

			return nil, errorss.BadRequest("can not update the book", updatedResult.Error.Error())
		}
		var responseBook models.BookInventory
		db.Where("id=?", oldBook.ID).Find(&responseBook)
		response["book"] = responseBook
		return response, nil
	}
	book.LibID = libId
	if err := db.Create(&book).Error; err != nil {
		return nil, errorss.BadRequest("failed to add book", err.Error())
	}
	response["book"] = book
	return response, nil
}

func (bookService *BookService) GetAllBook(userId uint, libId uint) ([]map[string]interface{}, *errorss.AppError) {

	var books []map[string]interface{}
	db := bookService.db
	var user models.User
	if err := db.Where("ID = ?", userId).First(&user).Error; err != nil {
		return nil, errorss.NotFound("User Not Found", err.Error())
	}
	if user.Role == "reader" {
		if err := db.Model(&models.BookInventory{}).
			Omit("total_copies", "available_copies", "lib_id", "CreatedAt", "DeletedAt", "UpdatedAt").
			Where("lib_id = ?", libId).Find(&books).Error; err != nil {
			return nil, errorss.NotFound("No Books Found", err.Error())
		}
		return books, nil
	}

	db.Model(&models.BookInventory{}).Where("lib_id = ?", libId).Find(&books)

	return books, nil
}

func (bookService *BookService) GetBook(id uint) (map[string]interface{}, *errorss.AppError) {

	db := bookService.db
	var response map[string]interface{}
	if err := db.Model(&models.BookInventory{}).Where("ID = ? ", id).First(&response).Error; err != nil {
		return nil, errorss.NotFound("Book Not Found", "book not found")
	}

	return response, nil

}

func (bookService *BookService) UpdateBook(userId, bookId uint, updatedBook dto.RequestUpdateBook) (map[string]interface{}, *errorss.AppError) {
	DB := bookService.db

	var book models.BookInventory
	var response = make(map[string]interface{})
	if err := DB.Model(&models.BookInventory{}).Where("ID = ?", bookId).First(&book).Error; err != nil {
		return nil, errorss.NotFound("book not Found", "book not found")
	}

	if err := auth.IsLibraryAdmin(DB, book.LibID, userId); err != nil {

		return nil, errorss.Forbidden("Can not Update Book", "you are not authorized to access this resource")
	}

	if err := DB.Model(&models.BookInventory{}).Where("id = ?", bookId).
		Updates(&updatedBook); err.Error != nil {

		return nil, errorss.BadRequest("Can not update the book", "failed to update the book")
	}
	DB.Model(&models.BookInventory{}).Where("ID = ?", bookId).First(&book)

	response["book"] = book
	return response, nil

}

func (bookService *BookService) DeleteBook(bookId, userId uint) *errorss.AppError {
	DB := bookService.db
	if result := DB.Where("id =? ", bookId).First(&book); result.Error != nil {
		return errorss.NotFound("Book Not Found", "book not found")
	}
	if err := auth.IsLibraryAdmin(DB, book.LibID, userId); err != nil {
		return errorss.Forbidden("Can not Delete Book", "you are not authorized to access this resource")
	}

	currentAvailable := book.AvailableCopies
	currentTotal := book.TotalCopies
	if book.AvailableCopies > 0 {
		currentAvailable -= 1
		currentTotal -= 1
	} else if book.AvailableCopies == 0 && book.TotalCopies > 0 {
		currentTotal -= 1
	} else if book.TotalCopies == 0 {
		return errorss.BadRequest("Can not delete book", "no copies available")
	}

	if result := DB.Where("id=?", bookId).Select("TotalCopies", "AvailableCopies").Updates(&models.BookInventory{TotalCopies: currentTotal, AvailableCopies: currentAvailable}); result.Error != nil {
		return errorss.BadRequest("Can not delete book", "failed to delete book")
	}

	log.Printf("available copies %v", currentAvailable)
	log.Printf("total copies %v", currentTotal)

	return nil

}

func (bookService *BookService) GetIssuedBook(readerId uint, libId uint) ([]map[string]interface{}, *errorss.AppError) {
	DB := bookService.db
	var issuedBooks []map[string]interface{}

	// result := DB.Model(&models.IssueRegistery{}).Select("b.*", "*").
	// 	Joins("JOIN book_inventories b on b.isbn = issue_registeries.isbn").
	// 	Where("reader_id = ? AND issue_registeries.issue_status=?", readerId, "issued").
	// 	Find(&issuedBooks)
	result := DB.Model(&models.IssueRegistery{}).
		Select("b.*, COALESCE(re.request_status, 'not_requested') AS return_status", "issue_registeries.expected_return_date").
		Joins("JOIN book_inventories b ON b.isbn = issue_registeries.isbn").
		Joins("LEFT JOIN request_events re ON re.book_id = b.id AND re.reader_id = issue_registeries.reader_id AND re.request_status = 'pending'").
		Where("issue_registeries.reader_id = ? AND issue_registeries.issue_status = ?", readerId, "issued").
		Find(&issuedBooks)
	if result.Error != nil {
		return nil, errorss.InternalServerError("No Books Found", "no books found")
	}

	return issuedBooks, nil
}

func (bookService *BookService) SearchBook(libId uint, payload *dto.SearchBookPayload) ([]models.BookInventory, *errorss.AppError) {

	db := bookService.db
	var searchedBooks []models.BookInventory

	result := db.Where("lib_id=? AND (authors = ? OR title = ? OR publisher = ? OR isbn=?)", libId, payload.Author, payload.Title, payload.Publisher, payload.ISBN).Find(&searchedBooks)
	if result.Error != nil {

		return nil, errorss.InternalServerError("No Books Found", result.Error.Error())
	}
	if len(searchedBooks) == 0 {

		return nil, errorss.NotFound("No Books Found", "no books found")

	}
	return searchedBooks, nil
}

func (bookService *BookService) GetBookStats(libId, userId uint) (map[string]interface{}, *errorss.AppError) {

	db := bookService.db
	var todayTime = time.Now()
	var totalBooks, availableBooks, overDue int64
	var bookAvailablity float32
	var user models.User
	var response = make(map[string]interface{})

	db.Where("id=?", userId).First(&user)

	db.Model(&models.BookInventory{}).
		Select("COALESCE(SUM(available_copies), 0)").
		Where("lib_id = ?", libId).
		Scan(&availableBooks)

	if user.Role == "admin" || user.Role == "owner" {
		// Total books (including all copies)
		db.Model(&models.BookInventory{}).
			Select("COALESCE(SUM(total_copies), 0)").
			Where("lib_id = ?", libId).
			Scan(&totalBooks)

		db.Model(&models.BookInventory{}).Joins("JOIN issue_registeries ig on ig.isbn = book_inventories.isbn").Where("ig.expected_return_date < ?", todayTime).Count(&overDue)
		bookAvailablity = (float32(availableBooks) / float32(totalBooks)) * 100

		response["totalBooks"] = totalBooks

		response["bookAvailablity"] = bookAvailablity
		response["overDue"] = overDue

	} else {
		var issueBooks int64
		db.Model(&models.BookInventory{}).Joins("join issue_registeries ig on ig.isbn  = book_inventories.isbn").Where("reader_id = ? AND issue_status =?", userId, "issued").Count(&issueBooks)
		response["issueBooks"] = issueBooks
	}

	response["availableBooks"] = availableBooks
	return response, nil

	// if
}

func (bookService *BookService) RecommendBook(userId uint, libId uint) (map[string]interface{}, *errorss.AppError) {

	var response = make(map[string]interface{})
	var bookHistory []models.BookInventory
	var popularBooks []struct {
		models.BookInventory
		BorrowCount int `json:"borrowCount" gorm:"column:borrow_count"`
	}
	var recommendedBooks []models.BookInventory
	var DB = bookService.db

	// 1. Fetch user's borrowing history
	DB.Model(&models.RequestEvent{}).
		Joins("JOIN book_inventories b ON b.id = request_events.book_id").
		Where("reader_id = ? AND request_type = ?", userId, "issue").
		Select("b.*").
		Find(&bookHistory)
	fmt.Printf("Book Histry :  %v", bookHistory)
	// 2. Get popular books
	DB.Table("issue_registeries").
		Select("b.*, COUNT(issue_registeries.issue_id) as borrow_count").
		Joins("JOIN book_inventories b ON b.isbn = issue_registeries.isbn").
		Group("b.id, b.title, b.authors, b.publisher, b.isbn, b.total_copies, b.available_copies").
		Order("borrow_count DESC").
		Limit(5).
		Scan(&popularBooks)
	var bookIds []uint
	var publishers []string
	var authors []string

	for _, book := range bookHistory {
		bookIds = append(bookIds, book.ID)
		publishers = append(publishers, book.Publisher)
		authors = append(authors, book.Authors)
	}

	fmt.Println(bookIds, publishers, authors)
	DB.Table("book_inventories").
		Where(" (authors IN (?)  OR publisher IN (?) ) AND id NOT IN (?)", authors, publishers, bookIds).
		Limit(5).
		Find(&recommendedBooks)

	// response["bookHistory"] = bookHistory
	response["popularBooks"] = popularBooks
	response["recommendedBooks"] = recommendedBooks

	return response, nil

}

func (bookService *BookService) GetReadingProgress(userId uint) []map[string]interface{} {

	var response []map[string]interface{}
	db := bookService.db
	db.Model(&models.IssueRegistery{}).Select("b.*", "issue_registeries.*").Joins("JOIN book_inventories b ON b.isbn = issue_registeries.isbn").Where("reader_id =? AND issue_status = ?", userId, "issued").Scan(&response)

	fmt.Println(response)
	for i, book := range response {
		expectedReturnDate, ok1 := book["expected_return_date"].(time.Time)
		issueDate, ok2 := book["issue_date"].(time.Time)

		if ok1 && ok2 {
			// Calculate total reading duration
			totalDuration := expectedReturnDate.Sub(issueDate).Hours() // in hours
			elapsedDuration := time.Since(issueDate).Hours()           // hours passed since issue date

			// Avoid division by zero
			var progress float64
			if totalDuration > 0 {
				progress = (elapsedDuration / totalDuration) * 100 // Progress in percentage
				if progress > 100 {
					progress = 100 // Cap at 100%
				}
			} else {
				progress = 100 // If issue & return date are the same, consider 100%
			}

			// Store reading progress
			response[i]["readingProgress"] = progress
		} else {
			response[i]["readingProgress"] = 0 // Default to 0% if dates are missing
		}
	}

	return response

}
