package book

import (
	"libraryManagement/internal/dto"
	"libraryManagement/internal/models"
	"libraryManagement/utility"
	"libraryManagement/validators"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type BookController struct {
	bookService BookService
}

// Setup new Book Controller
func NewBookController(db *gorm.DB) *BookController {
	bookService := BookService{db: db}
	return &BookController{bookService: bookService}
}

// Add New book controller
func (bc *BookController) AddBook(c *gin.Context) {
	var book models.BookInventory

	id := utility.GetContextItem(c, "id")
	libId := utility.GetContextItem(c, "libId")

	if err := c.ShouldBindJSON(&book); err != nil {
		utility.SendResponse(c, http.StatusBadRequest, false, "invalid request", nil, err.Error())
		return
	}
	if err := validators.Validate.Struct(book); err != nil {
		utility.SendResponse(c, 400, false, "validations error", nil, err.Error())
		return
	}

	response, err := bc.bookService.AddBook(id, libId, book)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}
	utility.SendResponse(c, 201, true, "Successfully Added Book", response)

}

// Get Book by id controller
func (bookController *BookController) GetBook(c *gin.Context) {

	bookId, valid := utility.GetParamItem(c, "id")
	userLib := utility.GetContextItem(c, "libId")
	if !valid {
		utility.SendResponse(c, 400, false, "invalid params", nil)
		return
	}

	book, err := bookController.bookService.GetBook(bookId)
	if err != nil {

		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}

	libId := book["lib_id"].(uint)

	if libId != userLib {
		utility.SendResponse(c, 403, false, "can not access book", nil, "You are not authorized to see this book")
		return
	}
	utility.SendResponse(c, 200, true, "Successfully get Book", book)

}

// Get all Books Controller
func (bc *BookController) GetAllBook(c *gin.Context) {

	libId := utility.GetContextItem(c, "libId")
	userId := utility.GetContextItem(c, "id")

	books, err := bc.bookService.GetAllBook(userId, libId)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}
	utility.SendResponse(c, http.StatusOK, true, "All Books Fetched", books)

}

// Delete book controller
func (bookController *BookController) DeleteBook(c *gin.Context) {
	bookId, valid := utility.GetParamItem(c, "id")
	userId := utility.GetContextItem(c, "id")
	if !valid {
		utility.SendResponse(c, 400, false, "invalid params", nil)
		return
	}

	if err := bookController.bookService.DeleteBook(bookId, userId); err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil)
		return
	}
	utility.SendResponse(c, 200, true, "Successfully Deleted the  Book", nil)
}

// Update Book Controller
func (bookController *BookController) UpdateBook(c *gin.Context) {
	var updatedBook dto.RequestUpdateBook

	libId := utility.GetContextItem(c, "libId")

	if err := c.ShouldBindBodyWithJSON(&updatedBook); err != nil {
		utility.SendResponse(c, 400, false, "invalid requrest body", nil)
		return
	}
	bookId, exist := utility.GetParamItem(c, "id")
	log.Printf("BookId %v", bookId)
	if !exist {
		utility.SendResponse(c, 400, false, "invalid params", nil)
		return
	}
	if !validators.IsValidateBook(updatedBook) {
		utility.SendResponse(c, 400, false, "validations error", nil, "inavlid body")
		return

	}
	if !exist {
		utility.SendResponse(c, 400, false, "invalid requrest params", nil, "inavlid params")
		return
	}
	userId := utility.GetContextItem(c, "id")
	book, err := bookController.bookService.GetBook(bookId)

	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}
	if book["lib_id"].(uint) != libId {
		utility.SendResponse(c, 403, false, "can not access book", nil, "you are not authorized to see this book")
		return
	}

	response, err := bookController.bookService.UpdateBook(userId, bookId, updatedBook)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}
	utility.SendResponse(c, 201, true, "Updated Succesfully ", response)
}

// Get Reader Issued Book Controller
func (bookController *BookController) GetIssuedBooks(c *gin.Context) {

	id := utility.GetContextItem(c, "id")
	libId := utility.GetContextItem(c, "libId")
	res, err := bookController.bookService.GetIssuedBook(id, libId)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)

	}
	utility.SendResponse(c, 200, true, "fetched all books", res)
}

// Search Book BY isbn ,  auth,  publisher  Controller
func (bc *BookController) SearchBooks(c *gin.Context) {
	var payload *dto.SearchBookPayload
	libId := utility.GetContextItem(c, "libId")

	if err := c.ShouldBindJSON(&payload); err != nil {

		utility.SendResponse(c, 400, false, "Error", nil, err.Error())
		return
	}
	res, err := bc.bookService.SearchBook(libId, payload)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}
	utility.SendResponse(c, 200, true, "Successfully fetch all books", res)
}

func (bc *BookController) GetBookStats(c *gin.Context) {

	userId := utility.GetContextItem(c, "id")
	libId := utility.GetContextItem(c, "libId")

	res, _ := bc.bookService.GetBookStats(libId, userId)
	utility.SendResponse(c, 200, true, "Successfully Fetched Book Stats", res)
}

func (bc *BookController) RecommendBook(c *gin.Context) {
	userId := utility.GetContextItem(c, "id")
	libId := utility.GetContextItem(c, "libId")

	res, _ := bc.bookService.RecommendBook(userId, libId)
	utility.SendResponse(c, 200, true, "Successfully Fetched Recommended Books", res)

}

func (bc *BookController) GetReadingProgress(c *gin.Context) {
	userId := utility.GetContextItem(c, "id")
	res := bc.bookService.GetReadingProgress(userId)
	utility.SendResponse(c, 200, true, "Successfully get ", res)
}
