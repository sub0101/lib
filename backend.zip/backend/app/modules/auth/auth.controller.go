package auth

import (
	"libraryManagement/internal/dto"
	"libraryManagement/internal/models"
	"libraryManagement/utility"
	"libraryManagement/validators"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type AuthController struct {
	authService AuthService
}

// Setup new Auth Controller
func NewAuthController(db *gorm.DB) *AuthController {

	authService := AuthService{DB: db}
	return &AuthController{authService: authService}
}

// Login Controller for validation checking
func (ac *AuthController) Login(c *gin.Context) {
	var body dto.RequestLoginBody
	if err := c.ShouldBindBodyWithJSON(&body); err != nil {
		utility.SendResponse(c, 400, false, "invalid body", nil, err.Error())
		return

	}
	if err := validators.Validate.Struct(body); err != nil {
		utility.SendResponse(c, 400, false, "invalid body", nil, err.Error())

		return
	}
	libId, id, role, err := ac.authService.Login(body)
	if err != nil {
		utility.SendResponse(c, err.Code, false, err.Message, nil, err.Details)
		return
	}
	token, _ := utility.CreateJwtToken(utility.JwtPayload{LibId: libId, Id: id, Role: role})

	c.SetCookie("jwt", token, 3600, "/", "localhost", false, true)
	utility.SendResponse(c, 200, true, "successfully logged in", token)
}

// Library and owner Registration Controller
func (ac *AuthController) SignupLibrary(c *gin.Context) {

	var body dto.RequestSignupLibraryBody

	if err := c.ShouldBindJSON(&body); err != nil {

		utility.SendResponse(c, 400, false, "invalid input body", nil, err.Error())
		return
	}
	hashPassword, err := utility.HashPassword(body.Password)
	if err != nil {
		utility.SendResponse(c, 501, false, "server side error", nil, err.Error())

	}
	if err := validators.Validate.Struct(body); err != nil {
		utility.SendResponse(c, 400, false, "invalid  body", nil, err.Error())
		return
	}
	auth := models.Auth{Email: body.Email, Password: hashPassword}
	library := models.Library{Name: body.LibraryName}
	user := models.User{Name: body.Name, Email: body.Email, ContactNumber: body.ContactNumber}

	response, errr := ac.authService.SignupLibrary(user, auth, library)
	if errr != nil {

		utility.SendResponse(c, errr.Code, false, errr.Message, nil, errr.Details)

		return
	}
	utility.SendResponse(c, 201, true, "Account created Successfully", response)

}

// Reader registration Controller
func (ac *AuthController) Signup(c *gin.Context) {
	var body dto.RequestSignupUserBody
	err := c.ShouldBindBodyWithJSON(&body)
	if err != nil {

		utility.SendResponse(c, 400, false, "invalid body", nil, err.Error())
		return
	}
	if err := validators.Validate.Struct(body); err != nil {
		utility.SendResponse(c, 400, false, "invalid  body", nil, err.Error())

		return
	}

	hashPassword, err := utility.HashPassword(body.Password)
	if err != nil {
		utility.SendResponse(c, 501, false, "Server Side Error", nil, err.Error())

	}
	user := models.User{Name: body.Name, Email: body.Email, ContactNumber: body.ContactNumber, LibId: body.LibId, Role: "reader"}

	auth := models.Auth{Email: body.Email, Password: hashPassword}

	response, errr := ac.authService.Signup(user, auth)
	if errr != nil {
		utility.SendResponse(c, errr.Code, false, errr.Message, nil, errr.Details)
		return
	}
	utility.SendResponse(c, 201, true, "Account Created Successfully", response)
}
