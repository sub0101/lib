package auth

import (
	"log"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Setup the Authentication Routes
func SetupAuthRouter(router *gin.RouterGroup, db *gorm.DB) {

	log.Printf("Auth Router Setup")
	authController := NewAuthController(db)
	authRouter := router.Group("/auth")
	{
		authRouter.POST("/login", authController.Login)
		authRouter.POST("/signup", authController.Signup)
		authRouter.POST("/library/signup", authController.SignupLibrary)

	}

}
