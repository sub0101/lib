package dto

type RequestUpdateLibrary struct {
	Name string `json:"name" binding:"required" validate:"alpha_space" `
}
