import React from 'react'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from './components/Auth/Login'
import ProtectedLogin from './components/Auth/ProtectedLogin';
import PrivateOutlet from './components/shared/PrivateOutlet';
import AdminPage from './pages/Admin/AdminPage';
import Home from './components/Home';
import { UserRegistration } from './components/Auth/UserRegistration';


import ManageRequests from './pages/Admin/ManageRequest/ManageRequests';
import ManageUser from './pages/Admin/Manage Users/ManageUser';


import PageNotFound from './components/shared/PageNotFound';
import ManageBooks from './pages/Admin/Manage Books/ManageBooks';
import ReaderPage from './pages/reader/ReaderPage';

import IssuedBooks from './pages/Reader/Books/IssuedBooks';
import ViewBooks from './pages/Reader/Books/Books';
import RequestTrack from './pages/Reader/RequestTracking/RequestTrack';
import ReaderDash from './pages/Reader/ReaderDashBoard/ReaderDashBoard';
import AdminDash from './pages/Admin/DashBoard/AdminDash';

function App() {
  return (
    <Router >
      <Routes>
        <Route path='/login' element={
          <ProtectedLogin>
            <Login />
          </ProtectedLogin>
        }
        />
         <Route path='/signup' element={
<ProtectedLogin >
< UserRegistration/>
</ProtectedLogin>
         
      
        }
        />

        <Route element={<PrivateOutlet />} >
          <Route element={<Home requiredRole={["admin", "owner"]} />} >
            <Route path="/admin" element={<AdminPage />} >
            <Route path='' element ={<AdminDash />} />
            <Route path='users' element ={<ManageUser/>} />
            <Route path='books' element={< ManageBooks/>} />
            <Route path='manage_request' element={<ManageRequests />} />
            </Route>  
          </Route>
          <Route path='*' element={<PageNotFound />} />
          
        </Route>

        <Route element={<PrivateOutlet />} >
          <Route element={<Home requiredRole={["reader"]} />} >
            <Route path="" element={<ReaderPage />} >
            <Route path='' element = {<ReaderDash />} />
            {/* <Route path='/contact' element={<Contactus />} /> */}
            <Route path='tracking' element={< RequestTrack/>} />
            <Route path='/issued' element={<IssuedBooks />} />
            <Route path='/books' element={<ViewBooks />} />
            </Route>
          </Route>
        </Route>

      </Routes>
    </Router>
  )
}

export default App