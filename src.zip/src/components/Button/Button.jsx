import React from 'react';
import { FaEdit } from 'react-icons/fa';
import styles from "./Button.module.css"
const Button = ({ value, color, icon, type, ...props }) => {

  return (
    <button
      className={` ${styles['Button']}  ${styles[`${type}Button`]} ${color ? styles[color] : ""}`}
      aria-label={value}
      {...props} >
      {icon}
      {value}
    </button>
  );
}

export default Button;
