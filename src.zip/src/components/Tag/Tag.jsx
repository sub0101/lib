import React from 'react';
import styles from "./Tag.module.css"

const Tag = ({type  , value}) => {
    return (
    <span className={`${styles.tag} ${ styles[`tag${type}`]}` }
        
    >
        {value}
                   </span>
    );
}

export default Tag;
