import React from 'react';
import classnames from 'classnames';

import { UsePagination } from './UsePagination';

import styles from './Pagination.module.scss';
const Pagination = props => {
  const {
    onPageChange,
    totalCount,
    siblingCount = 1,
    currentPage,
    pageSize,
    className
  } = props;
console.log(totalCount)
  const paginationRange = UsePagination({
    currentPage,
    totalCount,
    siblingCount,
    pageSize
  });

  // If there are less than 2 times in pagination range we shall not render the component
  if (currentPage === 0 || paginationRange?.length < 2) {
    return null;
  }

  const onNext = () => {
    onPageChange(currentPage + 1);
  };

  const onPrevious = () => {
    onPageChange(currentPage - 1);
  };

  let lastPage = paginationRange[paginationRange?.length - 1];
  return (
    <ul  key={1212667121}
      className={classnames(styles['pagination-container'], styles[`${className}`])}
    >
       {/* Left navigation arrow */}
      <li  key={1211442121}
        className={classnames(styles['pagination-item'], {
          disabled: currentPage === 1
        })}
        onClick={onPrevious}
      >
        <div className={classnames(styles["arrow"] ,styles["left"])} />
      </li>


      {paginationRange.map(pageNumber => {

        // If the pageItem is a DOT, render the DOTS unicode character
        if (pageNumber === "...") {
          return <li key={pageNumber} className={classnames(styles["pagination-item"] , styles['dots'])}>&#8230;</li>;
        }

        // Render our Page Pills
        return (
          <li
            className={classnames(styles['pagination-item'], {
              selected: pageNumber === currentPage
            })}
            onClick={() => onPageChange(pageNumber)}
          >
            {pageNumber}
          </li>
        );
      })}
      {/*  Right Navigation arrow */}
      <li key={212121212}
        className={classnames(styles['pagination-item'], {
          disabled: currentPage === lastPage
        })}
        onClick={onNext}
      >
        <div className={classnames(styles["arrow"] ,styles["right"])}/>
      </li>
    </ul>
  );
};

export default Pagination;