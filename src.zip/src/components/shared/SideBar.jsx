  import React from 'react'
  import styles from '../../style/admindash.module.css';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import { FaBook, FaCheck, FaDashcube, FaHome, FaList, FaServicestack, FaStreetView, FaSwatchbook, FaUser } from 'react-icons/fa';
  function SideBar({userRole}) {
    const navigate = useNavigate();
    const location = useLocation();
    const currentPath = location.pathname;
    
    const isActive = (path) => {
      if (path === '/admin' && (currentPath === '/admin' || currentPath === '/admin/dashboard')) {
        return true;
      }
      return currentPath.startsWith(path);
    };
  
    const navigateTo = (path) => {
      navigate(path);
    };

    

    return (
        <nav className={styles.sidebar}>
        <div className={styles.logo}>
          <h2>Library MS</h2>
        </div>
        {userRole=="admin" &&   <ul className={styles.menu}>
          <li 
            className={isActive('/admin') ? styles.active : ''}
            onClick={() => navigateTo('/admin')}
          >
            <div className={styles.menuItem}>
       
              <FaHome />
              <span>Dashboard</span>
            </div>
          </li>
          <li 
            className={isActive('/admin/users') ? styles.active : ''}
            onClick={() => navigateTo('/admin/users')}
          >
            <div className={styles.menuItem}>
           
              <FaUser />
              <span>Manage Users</span>
            </div>
          </li>
          <li 
            className={isActive('/admin/books') ? styles.active : ''}
            onClick={() => navigateTo('/admin/books')}
          >
            <div className={styles.menuItem}>
          
              <FaBook />
              <span>Manage Books</span>
            </div>
          </li>

          <li 
            className={isActive('/admin/manage_request') ? styles.active : ''}
            onClick={() => navigateTo('/admin/manage_request')}
          >
            <div className={styles.menuItem}>
              {/* <img src='/setting_i.png' alt="Settings" /> */}
              <FaList />
              <span>Manage Request</span>
            </div>
          </li>
        </ul>}

        {userRole == "reader" && 
           <ul className={styles.menu}>
         <li 
           className={isActive('/') ? styles.active : ''}
           onClick={() => navigateTo('/')}
         >
           <div className={styles.menuItem}>
         <FaHome />
             <span>Dashboard</span>
           </div>
         </li>
         <li 
           className={isActive('/books') ? styles.active : ''}
           onClick={() => navigateTo('/books')}
         >
           <div className={styles.menuItem}>
            <FaSwatchbook/>
             <span>View Books</span>
           </div>
         </li>
         <li 
           className={isActive('/issued') ? styles.active : ''}
           onClick={() => navigateTo('/issued')}
         >
           <div className={styles.menuItem}>
            <FaBook />
             <span>Manage Books</span>
           </div>
         </li>
         <li 
           className={isActive('/tracking') ? styles.active : ''}
           onClick={() => navigateTo('/tracking')}
         >
           <div className={styles.menuItem}>
            <FaList />
             <span>Request Tracking</span>
           </div>
         </li>
       </ul>
        }
       
      </nav>
    )
  }
  
  export default SideBar
 
