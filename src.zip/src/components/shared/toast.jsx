"use client"

import { useState, useEffect } from "react"
import style from  "../../style/toast.module.css"

const ToastNotification = ({ message, type ,duration = 3000, onClose }) => {
  const [visible, setVisible] = useState(true)
  console.log("toast notification")
  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false)
      setTimeout(() => {
        if (onClose) onClose()
      }, 300) // Wait for fade out a  nimation
    }, duration)

    return () => clearTimeout(timer)
  }, [duration, onClose])

  const handleClose = () => {
    setVisible(false)
    setTimeout(() => {
      if (onClose) onClose()
    }, 300) // Wait for fade out animation
  }
// `toast ${type} ${visible ? "visible" : ""}`
  return (
    <div className={`${style['toast']}  ${visible}  ${style.toastVisible}`}>
      <div className={style.toastContent}>
        <span className={style.toastMessage}>{message}</span>
        <button className={style.toastClose} onClick={handleClose}>
          ×
        </button>
      </div>
    </div>
  )
}


// <div className="app">
//       <h1>Toast Notification Demo</h1>

//       <div className="buttons">
//         <button onClick={() => showToast("success")}>Show Success</button>
//         <button onClick={() => showToast("error")}>Show Error</button>
//         <button onClick={() => showToast("info")}>Show Info</button>
//         <button onClick={() => showToast("warning")}>Show Warning</button>
//       </div>

//       {toast && <ToastNotification message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
//     </div>
export default ToastNotification

