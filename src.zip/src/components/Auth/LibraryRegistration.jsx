import React from 'react'

function LibraryRegistration() {
  return (
    <div> this is LibraryRegistration  Page</div>
  )
}

export default LibraryRegistration