import { data } from "react-router-dom"
import { authAxios } from "../axios"
import { getUserInfo } from "../../utils/auth/getUserInfo"

const URL="users/"
export const getAllUsers = async() =>{

    const response =  await authAxios.get(URL)
    console.log(response)
    return response.data.data

}

export const updateUser= async(payload) =>{
    const response = await authAxios.patch(`${URL}make_admin` , payload)
    return response.data.data
}

export const getUserDetail = async() =>{
    const userInfo =getUserInfo()
    console.log(userInfo)
    const response  =await authAxios.get(`${URL}${userInfo.Id}`)
    console.log(response.data.data)
    return response.data.data
}