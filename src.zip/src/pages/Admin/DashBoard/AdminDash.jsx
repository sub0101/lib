import { useEffect, useState } from "react"
import { getAllBooks, getBookStats, getRecommendedBooks } from "../../../react-queries/api/books"
import styles from "./AdminDash.module.css"
import { useQuery } from "@tanstack/react-query"
import { getRequestStats } from "../../../react-queries/api/requestEvents"

export default function AdminDash() {
  // Mock data
  const [totalBooks, setTotalBooks] = useState(0)
  const [totalUsers, setTotalUsers] = useState(0)
  const [activeRequests, setActiveRequests] = useState(0)


  const popularBooks = [
    { id: 1, title: "To Kill a Mockingbird", author: "Harper Lee", borrowCount: 124, cover: "/placeholder.svg" },
    { id: 2, title: "1984", author: "George Orwell", borrowCount: 98, cover: "/placeholder.svg" },
    { id: 3, title: "The Great Gatsby", author: "F. Scott Fitzgerald", borrowCount: 87, cover: "/placeholder.svg" },
    { id: 4, title: "Pride and Prejudice", author: "Jane Austen", borrowCount: 76, cover: "/placeholder.svg" },
  ]
  const recentActivity = [
    { id: 1, action: "Book Borrowed", user: "Sarah Johnson", book: "The Alchemist", timestamp: "2 hours ago" },
    { id: 2, action: "Book Returned", user: "Michael Chen", book: "Dune", timestamp: "5 hours ago" },
    { id: 3, action: "New User Registered", user: "Emma Wilson", book: "", timestamp: "1 day ago" },
    { id: 4, action: "Book Request", user: "David Brown", book: "The Hobbit", timestamp: "1 day ago" },
  ]

const [libraryHealth, setLibraryHealth] = useState({
  overDueBooks: 0,
  newMembers: 0,
  bookAvailablity: 0
})

const { data: bookStats, isSuccess } = useQuery({
  queryFn: getBookStats,
  queryKey: ["bookStats"]
})

const {data:requestStats , isReqStatSuccess} = useQuery({
  queryFn:getRequestStats,
  queryKey:["requestStats"]
})

const {data:popularBook ,isSuccess:isBookSuccessfull } = useQuery({
  queryFn:getRecommendedBooks,
  queryKey:["popularBooks"]
})
if (isBookSuccessfull) {
  console.log("success boooks")
  console.log(popularBook["popularBooks"])
}


useEffect(() => {
  setTotalBooks(bookStats?.totalBooks)
  setActiveRequests( requestStats &&  requestStats["pending"] ||  0)
  setLibraryHealth({ overDueBooks: bookStats?.overDueBooks, newMembers: 0, bookAvailablity: bookStats?.bookAvailablity })
}, [isSuccess , isReqStatSuccess])

return (
   <div className={styles.dashboard}>
    {bookStats ? (<>  <section className={styles.overviewSection}>
      <div className={styles.overviewCard}>
        <h2 className={styles.overviewTitle}>Total Books</h2>
        <p className={styles.overviewStat}>{totalBooks}</p>
      </div>
      <div className={styles.overviewCard}>
        <h2 className={styles.overviewTitle}>Total Users</h2>
        <p className={styles.overviewStat}>{totalUsers}</p>
      </div>
      <div className={styles.overviewCard}>
        <h2 className={styles.overviewTitle}>Active Requests</h2>
        <p className={styles.overviewStat}>{activeRequests}</p>
      </div>
    </section>

    <section className={styles.popularBooksSection}>
      <h2 className={styles.sectionTitle}>Most Popular Books</h2>
      <div className={styles.popularBooksList}>
        {isBookSuccessfull &&  popularBook["popularBooks"]?.map((book) => (
          <div key={book.id} className={styles.popularBookItem}>
            <img src={book.cover || "/placeholder.svg"} alt={book.title} className={styles.popularBookCover} />
            <div className={styles.popularBookInfo}>
              <p className={styles.popularBookTitle}>{book.title}</p>
              <p className={styles.popularBookAuthor}>{book.authors}</p>
            </div>
            <p className={styles.popularBookCount}>{book.borrowCount} borrows</p>
          </div>
        ))}
      </div>
    </section>

    <section className={styles.activitySection}>
      <h2 className={styles.sectionTitle}>Recent Activity</h2>
      <table className={styles.activityTable}>
        <thead>
          <tr>
            <th>Action</th>
            <th>User</th>
            <th>Book</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {recentActivity.map((activity) => (
            <tr key={activity.id}>
              <td>{activity.action}</td>
              <td>{activity.user}</td>
              <td>{activity.book || "-"}</td>
              <td>{activity.timestamp}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>

    <section className={styles.healthSection}>
      <h2 className={styles.sectionTitle}>Library Health</h2>
      <div className={styles.healthGrid}>
        <div className={styles.healthCard}>
          <h3 className={styles.healthTitle}>Overdue Books</h3>
          <p className={styles.healthStat}>{  bookStats.overDue}</p>
          <p className={styles.healthTrend + " " + styles.negative}>8% from last month</p>
        </div>
        <div className={styles.healthCard}>
          <h3 className={styles.healthTitle}>New Members</h3>
          <p className={styles.healthStat}>48</p>
          <p className={styles.healthTrend}>12% from last month</p>
        </div>
        <div className={styles.healthCard}>
          <h3 className={styles.healthTitle}>Book Availability</h3>
          <p className={styles.healthStat}>{bookStats.bookAvailablity} %</p>
        </div>
      </div>
    </section></>
    ) : 
  (  <p> Loading</p>  )}
  </div>
)
}

