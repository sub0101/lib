"use client"

import { useEffect, useState } from "react"
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { updateRequest, getAllAdminRequest } from "../../../react-queries/api/requestEvents"
import styles from "./ManageRequest.module.css"

const ManageRequests = () => {
  const queryClient = useQueryClient()
  const [activeRow, setActiveRow] = useState(null)
  const [updateRequestIndex, setUpdateRequestIndex] = useState()

  const { data: requests, isSuccess: getRequestSuccess, isLoading: getRequestLoading } = useQuery({
    queryFn: getAllAdminRequest,
    queryKey: ["getRequests"],
  })

  const requestMutation = useMutation({
    mutationFn: updateRequest,
    mutationKey: "update  request",
    onSuccess: () => {
    
      updateTheRowStatus()
    }

  })

  const updateTheRowStatus = () => {

    queryClient.setQueryData(["getRequests"], (oldData) => {
      const newData = [...oldData];
      if (newData[updateRequestIndex]) {
        newData[updateRequestIndex] = {
          ...newData[updateRequestIndex],
          request_status: "accepted"

        };

      }
      return newData;
    })

  }

  const handleApprove = (data) => {
   
    alert(`Request with ID ${data.reqId} approved!`)
    setUpdateRequestIndex(data.ind)
    requestMutation.mutate({ id: data.reqId, requestType: "accepted" })


  }


  const handleReject = (id) => {
    alert(`Request with ID ${id} rejected!`)
    requestMutation.mutate({ id: id, requestType: "rejected" })
  }

  const getStatusClass = (status) => {
    if (!status) return styles.pending
    return status.toLowerCase() === "approved" ? styles.approved : styles.rejected
  }

  return (
    <div className={styles.adminContainer}>
      <div className={styles.adminHeader}>
        <h1 className={styles.adminTitle}>Manage Requests</h1>
        <div className={styles.adminSubtitle}>Review and process pending book requests</div>
      </div>

      {getRequestLoading ? (
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Loading requests...</p>
        </div>
      ) : requests && requests.length > 0 ? (
        <div className={styles.tableContainer}>
          <table className={styles.requestTable}>
            <thead>
              <tr>
                <th>Book Title</th>
                <th>Request ID</th>
                <th>Request Type</th>
                <th>Date</th>
                <th>Status/Actions</th>
              </tr>
            </thead>
            <tbody>


              {requests.map((request, index) => (
                <tr
                  key={request.req_id}
                  className={activeRow === request.req_id ? styles.activeRow : ""}
                  onMouseEnter={() => setActiveRow(request.req_id)}
                  onMouseLeave={() => setActiveRow(null)}
                >
                  <td className={styles.bookTitle}>{request.title}</td>
                  <td>{request.req_id}</td>
                  <td>
                    <span className={styles.requestType}>{request.request_type}</span>
                  </td>
                  <td>{new Date(request.request_date).toLocaleDateString()}</td>
                  {request.request_status == "pending" ? (
                    <td className={styles.actionButtons}>
                      <button className={styles.approveButton} onClick={() => handleApprove({ ind: index, reqId: request.req_id })} >
                        Approve
                      </button>
                      <button className={styles.rejectButton} onClick={() => handleApprove(request.req_id)}>
                        Reject
                      </button>
                    </td>
                  ) : (
                    <td>
                      <span className={`${styles.statusBadge} ${getStatusClass(request.request_status)}`}>
                        {request.request_status}
                      </span>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}>📚</div>
          <h3>No requests found</h3>
          <p>There are currently no book requests to review</p>
        </div>
      )}
    </div>
  )
}

export default ManageRequests