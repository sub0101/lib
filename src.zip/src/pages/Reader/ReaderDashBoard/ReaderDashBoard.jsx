
"use client"

import { useState } from "react"

import styles from "./ReaderDashBoard.module.css"
import { useQuery } from "@tanstack/react-query"
import { getBooksProgress, getBookStats, getRecommendedBooks } from "../../../react-queries/api/books"
import { Link } from "react-router-dom"
import { getUserDetail } from "../../../react-queries/api/users"


export default function ReaderDash() {
  // Mock data
    const [availableBooks , setAvailableBooks] = useState(0)
    const [borrowedBooks , setBorrowedBooks] = useState(0)

  const userData = {
    name: "John Reader",
    recommendations: [
      { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", cover: "/placeholder.svg" },
      { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", cover: "/placeholder.svg" },
      { id: 3, title: "1984", author: "George Orwell", cover: "/placeholder.svg" },
      { id: 4, title: "Pride and Prejudice", author: "Jane Austen", cover: "/placeholder.svg" },
    ],
    currentlyReading: [
      { id: 1, title: "The Catcher in the Rye", author: "J.D. Salinger", progress: 65, dueDate: "2025-03-20" },
      { id: 2, title: "Brave New World", author: "Aldous Huxley", progress: 30, dueDate: "2025-03-25" },
    ],
  }


  const { data: bookStats,isSuccess } = useQuery({
    queryFn: getBookStats,
    queryKey: ["bookStats"]
  })
  const {data:recommendations ,isSuccess:recommendSuccess} = useQuery({
    queryFn :getRecommendedBooks ,
    queryKey:["recommendedBooks" ,"popularBooks"]
  })

  const {data:userDetails , isSuccess:userSuccess} = useQuery({
    queryFn:getUserDetail,
    queryKey:["userDetails"]
  })

  const {data:currentlyReading , isSuccess:progressSuccess} = useQuery({
    queryFn:getBooksProgress , 
    queryKey:["bookProgress"]
  })

  
  const getGreeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Good morning"
    if (hour < 18) return "Good afternoon"
    return "Good evening"
  }

  return (
    <div className={styles.dashboard}>
        { bookStats && (  <> 
        
            <section className={styles.welcomeSection}>
        <h1 className={styles.welcomeTitle}>
          {getGreeting()}, {userDetails?.name}!
        </h1>
        <p>Welcome back to your library dashboard. You have {userData.borrowedBooks} books currently borrowed.</p>
      </section>

      <section className={styles.overviewSection}>
        <div className={styles.overviewCard}>
          <h2 className={styles.overviewTitle}>Books Available</h2>
          <p className={styles.overviewStat}>{bookStats.availableBooks}</p>
        </div>
        <div className={styles.overviewCard}>
          <h2 className={styles.overviewTitle}>Books Borrowed</h2>
          <p className={styles.overviewStat}>{bookStats.issueBooks  }</p>
        </div>
      </section>

      <section className={styles.recommendationsSection}>
        <h2 className={styles.recommendationsTitle}>Recommended For You</h2>
        <div className={styles.recommendationsList}>
          {recommendations?.recommendedBooks
.map((book) => (
            <div key={book.id} className={styles.recommendationItem}>
              <img src={book?.cover || "/book_placeholder.jpg"} alt={book.title} className={styles.recommendationCover} />
            <Link to="/books" >   <p className={styles.recommendationTitle}>{book.title}</p> </Link>
              <p className={styles.recommendationAuthor}>{book.authors}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.progressSection}>
        <h2 className={styles.progressTitle}>Your Reading Progress</h2>
        {currentlyReading?.map((book) => (
          <div key={book.id} className={styles.progressItem}>
            <div className={styles.progressInfo}>
              <div>
                <p className={styles.progressTitle}>{book.title}</p>
                <p className={styles.progressAuthor}>{book.author}</p>
              </div>
              <div>
                <p>Due: {new Date(book.expected_return_date).toLocaleDateString()}</p>
                <p>{(book.readingProgress).toFixed(2)}% complete</p>
              </div>
            </div>
            <div className={styles.progressBar}>
              <div className={styles.progressFill} style={{ width: `${(book.readingProgress).toFixed(2)}%` }}></div>
            </div>
          </div>
        ))}
      </section>
        </>)}
    
    </div>
  )
}

