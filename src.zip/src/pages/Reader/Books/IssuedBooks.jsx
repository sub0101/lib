import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import styles from "./IssuedBooks.module.css"
import { useState } from "react"
import { getIssuesBooks } from "../../../react-queries/api/books"
import { addReturnRequest } from "../../../react-queries/api/requestEvents"
import Button from "../../../components/Button/Button"
import { FaBackspace, FaBackward, FaCaretSquareDown, FaRegArrowAltCircleLeft, FaRegObjectUngroup } from "react-icons/fa"
import { setLocalStorage } from "../../../utils/localStorage"
import Tag from "../../../components/Tag/Tag"

function IssuedBooks() {
  const [payload , setPayload] = useState({})
  const[returnBookIndex , setReturnBookIndex] = useState(0)
  const queryCient = useQueryClient()
const returnRequestMutation = useMutation({
  mutationFn:addReturnRequest,
  mutationKey :"return request",
  onSuccess:()=>{
    updateTheReturnStatus()
  } 
})

const updateTheReturnStatus = () => {

  queryCient.setQueryData(["issued"], (oldData) => {
    console.log(oldData)
    const newData = [...oldData];
    if (newData[returnBookIndex]) {
      newData[returnBookIndex] = {
        ...newData[returnBookIndex],
        return_status: "pending"

      };

    }
    console.log(newData)
    return newData;
  })

}
  const today = new Date().toISOString().split("T")[0] 

  const handleReturn = (book) => {
    const confirmReturn = window.confirm(`Are you sure you want to return "${book.bookTitle}"?`)
    if (confirmReturn) {
      setReturnBookIndex(book.index)
      payload.bookId = book.id
      payload.requestType = "return"
      returnRequestMutation.mutate(payload)
     
    
    }
  }

  const {data:issuedBooks} = useQuery ({
    queryKey:["issued"],
    queryFn:getIssuesBooks
  })
  
  return (
    <div className={styles.issuedBooks}>
      <h1>Issued Books</h1>
      <table className={styles.bookTable}>
        <thead>
          <tr>
            <th>Title</th>
            <th>Due Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          { issuedBooks && issuedBooks.map((book ,index) => (
            <tr key={book.id}>
              <td>{book.title}</td> 
              <td className={book.expectedReturnDate < today ? styles.overdue : ""}>{ new Date(book.expected_return_date).toLocaleDateString() }</td>
              <td>
      
            { book.return_status !="pending" &&
            
            ( <Button type={"large"} value={"Return Book"}
                icon={<FaRegArrowAltCircleLeft/> } color={"red"}                 
                  onClick={() => handleReturn({ index: index , id:book.id, bookTitle:book.title})}
                />)  || <Tag type={"warning"} value={book.return_status} />}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default IssuedBooks
