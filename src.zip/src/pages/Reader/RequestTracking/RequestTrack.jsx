import { useQuery } from "@tanstack/react-query"
// import styles from "./RequestTrack.module.css"
import { getAllRequest } from "../../../react-queries/api/requestEvents"
import Tag from "../../../components/Tag/Tag"
import styles from "../../../style/managerequest.module.css"
import Pagination from "../../../components/Pagination/Pagination"
import { useState,useMemo, useEffect } from "react"

function RequestTrack() {

  const  {data:requests ,isSuccess , isLoading} = useQuery({
    queryKey:["requests"],
    queryFn:getAllRequest
  })

  const[currentTableData , setCurrentTableData] = useState([])
  const [currentPage, setCurrentPage] = useState(1);

  let PageSize = 10;


 const pageData =    useMemo(() => {
      const firstPageIndex = (currentPage - 1) * PageSize;
      const lastPageIndex = firstPageIndex + PageSize;
   
      return requests?.slice(firstPageIndex, lastPageIndex);
    }, [currentPage,requests]);




  const getStatusClass = (status) => {
    if (!status) return styles.pending
    return status.toLowerCase() === "approved" ? styles.approved : styles.rejected
  }
  return (


   <div className={styles.adminContainer}>
      <div className={styles.adminHeader}>
        <h1 className={styles.adminTitle}>Request Tracking</h1>
        <div className={styles.adminSubtitle}>Review and process pending book requests</div>
      </div>

      {isLoading ? (
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Loading requests...</p>
        </div>
      ) : requests && requests.length > 0 ? (
        <> <div className={styles.tableContainer}>
         
        <table className={styles.requestTable}>
          <thead>
            <tr>
              <th>Book Title</th>
              <th>Request Type</th>
              <th>Request Date</th>
              
              <th>Request Update Date</th>
              <th>Status/Actions</th>
            </tr>
          </thead>
          <tbody>
              { pageData?.map((request) => (
                <tr
                  key={request.requestId}
                  
                >
                  <td className={styles.bookTitle}>{request.Book.title}</td>
              
                  <td>
                        <span className={`${styles.requestType} ${styles[request.requestType.toLowerCase()]}`}>
         {request.requestType}
          </span>
                  </td>
                  <td>{new Date(request.requestDate).toLocaleDateString()}</td>

                  <td>{ request.approvalDate &&  new Date(request.approvalDate).toLocaleDateString() ||  "Yet to Update"}</td>
                    <td>
                     <Tag value={request.requestStatus} type={  `${request.requestStatus =="accepted" ? "success" :"danger"}`  } />

                    </td>
                  
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <Pagination
      className="pagination-bar"
      currentPage={currentPage}
      totalCount={requests?.length}
      pageSize={PageSize}
      onPageChange={page => setCurrentPage(page)} />
      
       </>
       
     
      ) : (
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}>📚</div>
          <h3>No requests found</h3>
          <p>There are currently no book requests to review</p>
         
        </div>

       
      )
      }
    </div>
  )
}

export default RequestTrack
